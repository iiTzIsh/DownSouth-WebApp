package com.agent.service;

/**
 * Agent Implementation
 * 
 * @author H.P.I Madusanka - IT22259134
 */

import java.util.ArrayList;

import com.agent.model.Agent;

public interface IAgentService {
	
	public void addAgent(Agent agent);
	
	public ArrayList<Agent> getAgents();
	
	public ArrayList<Agent> getAgentById(String agentId);
	
	public void updateAgent(String agentId, Agent agent);
	
	public void deleteAgent(String agentId);


	

}
