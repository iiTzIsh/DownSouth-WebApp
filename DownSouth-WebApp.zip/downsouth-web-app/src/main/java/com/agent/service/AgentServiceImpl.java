package com.agent.service;

/**
 * Agent Implementation
 * 
 * @author H.P.I Madusanka - IT22259134
 */

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.xml.parsers.ParserConfigurationException;

import org.xml.sax.SAXException;


import com.agent.model.Agent;
import com.agent.util.CommanConstants;
import com.agent.util.CommonUtil;
import com.agent.util.DBConnection;
import com.agent.util.QueryUtil;

public class AgentServiceImpl implements IAgentService{
	
	private static Connection connection;
	private static java.sql.Statement stmt;
	private static PreparedStatement preparedStatement;
	
	static {
		createAgentTable();
		
	}
	
	public static void createAgentTable() { 
		try {
			
			connection = DBConnection.getDBConnection();
			
			stmt = connection.createStatement();
			stmt.execute(QueryUtil.queryByID(CommanConstants.QUERY_ID_CREATE_AGENT_TABLE));
			
			 
			
		}catch(SQLException | SAXException | IOException | ParserConfigurationException | ClassNotFoundException e){
			System.out.println("Create table exception" + e.getMessage());
		}finally {
			try {
				
				if(connection != null) {
					connection.close();
				}
				
				if(stmt != null) {
					stmt.close();
				}
				
			}catch(SQLException e){
				System.out.println(e.getMessage());
			}
		}
		
		
	};
	
	@Override
	public void addAgent(Agent agent) {
		
		String agentId = CommonUtil.generateAgentsIds(getAgentIds());
		
		try {
			
			connection = DBConnection.getDBConnection();
			
			preparedStatement = connection.prepareStatement(QueryUtil.queryByID(CommanConstants.QUERY_ID_INSERT_AGENT_TABLE));
			connection.setAutoCommit(false);
			
			agent.setAgentId(agentId);
			
			preparedStatement.setString(CommanConstants.COLUMN_INDEX_ONE, agent.getAgentId());
			preparedStatement.setString(CommanConstants.COLUMN_INDEX_TWO, agent.getFirstName());
			preparedStatement.setString(CommanConstants.COLUMN_INDEX_THREE, agent.getLastName());
			preparedStatement.setString(CommanConstants.COLUMN_INDEX_FOUR, agent.getAddress());
			preparedStatement.setString(CommanConstants.COLUMN_INDEX_FIVE, agent.getMobileNo());
			preparedStatement.setString(CommanConstants.COLUMN_INDEX_SIX, agent.getDepartment());
			
			preparedStatement.executeLargeUpdate();
			connection.commit();
			
		}catch(SQLException | SAXException | IOException | ParserConfigurationException | ClassNotFoundException e) {
			System.out.println(e.getMessage());
		}
		
	}

	@Override
	public ArrayList<Agent> getAgents() {
		
		ArrayList<Agent> agentList = new ArrayList<Agent>();
		
		try {
			
			connection = DBConnection.getDBConnection();
			preparedStatement = connection.prepareStatement(QueryUtil.queryByID(CommanConstants.QUERY_ID_GET_ALL_AGENTS));

			ResultSet rs = preparedStatement.executeQuery();
			
			while(rs.next()){
				Agent ag = new Agent();
				
				ag.setAgentId(rs.getString(CommanConstants.COLUMN_INDEX_ONE));
				ag.setFirstName(rs.getString(CommanConstants.COLUMN_INDEX_TWO));
				ag.setLastName(rs.getString(CommanConstants.COLUMN_INDEX_THREE));
				ag.setAddress(rs.getString(CommanConstants.COLUMN_INDEX_FOUR));
				ag.setMobileNo(rs.getString(CommanConstants.COLUMN_INDEX_FIVE));
				ag.setDepartment(rs.getString(CommanConstants.COLUMN_INDEX_SIX));
				
				agentList.add(ag);
			}
			
		}catch(SQLException | SAXException | IOException | ParserConfigurationException | ClassNotFoundException e) {
			System.out.println(e.getMessage());
		}finally {
			try {
				
				if(connection != null) {
					connection.close();
				}
				
				if(stmt != null) {
					stmt.close();
				}
				
			}catch(SQLException e){
				System.out.println(e.getMessage());
			}
		}
		
		
		return agentList;
	}

	@Override
	public ArrayList<Agent> getAgentById(String agentId) {
		
		ArrayList<Agent> agentList = new ArrayList<Agent>();
		
		try {
			
			connection = DBConnection.getDBConnection();
			preparedStatement = connection.prepareStatement(QueryUtil.queryByID(CommanConstants.QUERY_ID_GET_AGENT_BY_ID));
			
			preparedStatement.setString(CommanConstants.COLUMN_INDEX_ONE,agentId);
			
			ResultSet rs = preparedStatement.executeQuery();
			
			while(rs.next()){
				Agent ag = new Agent();
				
				ag.setAgentId(rs.getString(CommanConstants.COLUMN_INDEX_ONE));
				ag.setFirstName(rs.getString(CommanConstants.COLUMN_INDEX_TWO));
				ag.setLastName(rs.getString(CommanConstants.COLUMN_INDEX_THREE));
				ag.setAddress(rs.getString(CommanConstants.COLUMN_INDEX_FOUR));
				ag.setMobileNo(rs.getString(CommanConstants.COLUMN_INDEX_FIVE));
				ag.setDepartment(rs.getString(CommanConstants.COLUMN_INDEX_SIX));
				
				agentList.add(ag);
			}
			
		}catch(SQLException | SAXException | IOException | ParserConfigurationException | ClassNotFoundException e) {
			System.out.println(e.getMessage());
		}finally {
			try {
				
				if(connection != null) {
					connection.close();
				}
				
				if(stmt != null) {
					stmt.close();
				}
				
			}catch(SQLException e){
				System.out.println(e.getMessage());
			}
		}
		
		
		return agentList;
	}

	@Override
	public void updateAgent(String agentId, Agent agent) {
		
		try {
			
			connection = DBConnection.getDBConnection();
			
			preparedStatement = connection.prepareStatement(QueryUtil.queryByID(CommanConstants.QUERY_ID_UPDATE_AGENT));
			connection.setAutoCommit(false);
			
			preparedStatement.setString(CommanConstants.COLUMN_INDEX_ONE, agent.getFirstName());
			preparedStatement.setString(CommanConstants.COLUMN_INDEX_TWO, agent.getLastName());
			preparedStatement.setString(CommanConstants.COLUMN_INDEX_THREE, agent.getAddress());
			preparedStatement.setString(CommanConstants.COLUMN_INDEX_FOUR, agent.getMobileNo());
			preparedStatement.setString(CommanConstants.COLUMN_INDEX_FIVE, agent.getDepartment());
			preparedStatement.setString(CommanConstants.COLUMN_INDEX_SIX, agent.getAgentId());

			preparedStatement.executeLargeUpdate();
			connection.commit();
			
		}catch(SQLException | SAXException | IOException | ParserConfigurationException | ClassNotFoundException e) {
			System.out.println(e.getMessage());
		}
		
	}

	@Override
	public void deleteAgent(String AgentId) {
		
		if(AgentId != null && !AgentId.isEmpty()) {
			
			try {
				
				connection = DBConnection.getDBConnection();
				
				preparedStatement = connection.prepareStatement(QueryUtil.queryByID(CommanConstants.QUERY_ID_DELETE_AGENT));
				preparedStatement.setString(CommanConstants.COLUMN_INDEX_ONE,AgentId);

				preparedStatement.execute();
				
			}catch(SQLException | SAXException | IOException | ParserConfigurationException | ClassNotFoundException e){
				System.out.println(e.getMessage());

			}finally {
				try {
					
					if(connection != null) {
						connection.close();
					}
					
					if(stmt != null) {
						stmt.close();
					}
					
				}catch(SQLException e){
					System.out.println(e.getMessage());
				}
			}
			
		}
		
	}
	
	
	
	
	
	public ArrayList<String> getAgentIds(){
		ArrayList<String> ids = new ArrayList<String>();
		
		try {
			
			connection = DBConnection.getDBConnection();
			preparedStatement = connection.prepareStatement(QueryUtil.queryByID(CommanConstants.QUERY_ID_GET_AGENT_IDS));
		    ResultSet	rs = preparedStatement.executeQuery();
			
			while(rs.next()) {
				ids.add(rs.getString(CommanConstants.COLUMN_INDEX_ONE));
			}
			
		}catch(SQLException | SAXException | IOException | ParserConfigurationException | ClassNotFoundException e) {
			System.out.println(e.getMessage());
		}finally {
			try {
				
				if(connection != null) {
					connection.close();
				}
				
				if(preparedStatement != null) {
					preparedStatement.close();
				}
				
			}catch(SQLException e){
				System.out.println(e.getMessage());
			}
		}
		
		return ids;
	}
	

}
