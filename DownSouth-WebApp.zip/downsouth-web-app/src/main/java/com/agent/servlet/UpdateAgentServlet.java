package com.agent.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.agent.model.Agent;
import com.agent.service.IAgentService;
import com.agent.service.AgentServiceImpl;

/**
 * Servlet implementation class UpdateAgentServlet
 */
@WebServlet("/UpdateAgentServlet")
public class UpdateAgentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateAgentServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		
		Agent agent = new Agent();
		
		String agentId = request.getParameter("studentId");
		
		agent.setAgentId(agentId);
		
		agent.setFirstName(request.getParameter("firstname"));
		agent.setLastName(request.getParameter("lastname"));
		agent.setAddress(request.getParameter("address"));
		agent.setMobileNo(request.getParameter("mobileno"));
		agent.setDepartment(request.getParameter("department"));
		
		IAgentService iagentService = new AgentServiceImpl();
		iagentService.updateAgent(agentId,agent);
		
		
		request.setAttribute("agent", agent);
		RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/allAgents.jsp");
		dispatcher.forward(request, response);
	}

}
