package com.feedback.service;

import java.util.ArrayList;


import com.feedback.model.Feedback;

public interface IFeedbackService {
	
	public void addFeedback(Feedback feedback);
	
	public ArrayList<Feedback> getFeedbacks();
	
	public ArrayList<Feedback> getFeedbackById(String feedbackId);
	
	public void updateFeedback(String feedbackId, Feedback feedback);
	
	public void deleteFeedback(String feedbackId);

}
