package com.feedback.service;

import java.io.IOException;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.xml.parsers.ParserConfigurationException;

import org.xml.sax.SAXException;

import com.feedback.model.Feedback;
import com.feedback.util.CommanConstants;
import com.feedback.util.CommonUtil;
import com.feedback.util.DBConnection;
import com.feedback.util.QueryUtil;

public class FeedbackServiceImpl implements IFeedbackService{
	
	private static Connection connection;
	private static java.sql.Statement stmt;
	private static PreparedStatement preparedStatement;
	
	static {
		createFeedbackTable();
		 
	}
	
	public static void createFeedbackTable() { 
		try {
			
			connection = DBConnection.getDBConnection();
			
			stmt = connection.createStatement();
			stmt.execute(QueryUtil.queryByID(CommanConstants.QUERY_ID_CREATE_FEEDBACK_TABLE));
			
			
			
		}catch(SQLException | SAXException | IOException | ParserConfigurationException | ClassNotFoundException e){
			System.out.println("Create table exception" + e.getMessage());
		}finally {
			try {
				
				if(connection != null) {
					connection.close();
				}
				
				if(stmt != null) {
					stmt.close();
				}
				
			}catch(SQLException e){
				System.out.println(e.getMessage());
			}
		}
		
		
	};
	
	@Override
	public void addFeedback(Feedback feedback) {
		
		String feedbackId = CommonUtil.generateFeedbackIds(getFeedbackIds());
		
		try {
			
			connection = DBConnection.getDBConnection();
			
			preparedStatement = connection.prepareStatement(QueryUtil.queryByID(CommanConstants.QUERY_ID_INSERT_FEEDBACK));
			connection.setAutoCommit(false);
			
			feedback.setFeedbackId(feedbackId);
			
			preparedStatement.setString(CommanConstants.COLUMN_INDEX_ONE, feedback.getFeedbackId());
			preparedStatement.setString(CommanConstants.COLUMN_INDEX_TWO, feedback.getName());
			preparedStatement.setString(CommanConstants.COLUMN_INDEX_THREE,feedback.getRating());
			preparedStatement.setString(CommanConstants.COLUMN_INDEX_FOUR, feedback.getNote());
			preparedStatement.setString(CommanConstants.COLUMN_INDEX_FIVE, feedback.getMobileNo());
			
			preparedStatement.executeLargeUpdate();
			connection.commit();
			
		}catch(SQLException | SAXException | IOException | ParserConfigurationException | ClassNotFoundException e) {
			System.out.println(e.getMessage());
		}finally {
			try {
				
				if(connection != null) {
					connection.close();
				}
				
				if(preparedStatement != null) {
					preparedStatement.close();
				}
				
			}catch(SQLException e){
				System.out.println(e.getMessage());
			}
		}
		
		
	}

	@Override
	public ArrayList<Feedback> getFeedbacks() {
		
		ArrayList<Feedback> feedbackList = new ArrayList<Feedback>();
		
		try {
			
			connection = DBConnection.getDBConnection();
			preparedStatement = connection.prepareStatement(QueryUtil.queryByID(CommanConstants.QUERY_ID_GET_ALL_FEEDBACKS));

			ResultSet rs = preparedStatement.executeQuery();
			
			while(rs.next()){
				Feedback fed = new Feedback();
				
				fed.setFeedbackId(rs.getString(CommanConstants.COLUMN_INDEX_ONE));
				fed.setName(rs.getString(CommanConstants.COLUMN_INDEX_TWO));
				fed.setRating(rs.getString(CommanConstants.COLUMN_INDEX_THREE));
				fed.setNote(rs.getString(CommanConstants.COLUMN_INDEX_FOUR));
				fed.setMobileNo(rs.getString(CommanConstants.COLUMN_INDEX_FIVE));
				
				feedbackList.add(fed);
			}
			
		}catch(SQLException | SAXException | IOException | ParserConfigurationException | ClassNotFoundException e) {
			System.out.println(e.getMessage());
		}finally {
			try {
				
				if(connection != null) {
					connection.close();
				}
				
				if(preparedStatement != null) {
					preparedStatement.close();
				}
				
			}catch(SQLException e){
				System.out.println(e.getMessage());
			}
		}
		
		
		return feedbackList;
	}

	@Override
	public ArrayList<Feedback> getFeedbackById(String feedbackId) {
		
		ArrayList<Feedback> feedbackList = new ArrayList<Feedback>();
		
		try {
			
			connection = DBConnection.getDBConnection();
			preparedStatement = connection.prepareStatement(QueryUtil.queryByID(CommanConstants.QUERY_ID_GET_FEEDBACK_BY_ID));
			
			preparedStatement.setString(CommanConstants.COLUMN_INDEX_ONE,feedbackId);
			
			ResultSet rs = preparedStatement.executeQuery();
			
			while(rs.next()){
				Feedback fed = new Feedback();
				
				fed.setFeedbackId(rs.getString(CommanConstants.COLUMN_INDEX_ONE));
				fed.setName(rs.getString(CommanConstants.COLUMN_INDEX_TWO));
				fed.setRating(rs.getString(CommanConstants.COLUMN_INDEX_THREE));
				fed.setNote(rs.getString(CommanConstants.COLUMN_INDEX_FOUR));
				fed.setMobileNo(rs.getString(CommanConstants.COLUMN_INDEX_FIVE));
				
				feedbackList.add(fed);
			}
			
		}catch(SQLException | SAXException | IOException | ParserConfigurationException | ClassNotFoundException e) {
			System.out.println(e.getMessage());
		}finally {
			try {
				
				if(connection != null) {
					connection.close();
				}
				
				if(stmt != null) {
					stmt.close();
				}
				
			}catch(SQLException e){
				System.out.println(e.getMessage());
			}
		}
		
		
		return feedbackList;
	}

	@Override
	public void updateFeedback(String feedbackId, Feedback feedback) {
		
		try {
			
			connection = DBConnection.getDBConnection();
			
			preparedStatement = connection.prepareStatement(QueryUtil.queryByID(CommanConstants.QUERY_ID_UPDATE_FEEDBACK));
			connection.setAutoCommit(false);
			
			preparedStatement.setString(CommanConstants.COLUMN_INDEX_ONE, feedback.getName());
			preparedStatement.setString(CommanConstants.COLUMN_INDEX_TWO, feedback.getRating());
			preparedStatement.setString(CommanConstants.COLUMN_INDEX_THREE,feedback.getNote());
			preparedStatement.setString(CommanConstants.COLUMN_INDEX_FOUR, feedback.getMobileNo());
			preparedStatement.setString(CommanConstants.COLUMN_INDEX_FIVE, feedback.getFeedbackId());

			preparedStatement.executeLargeUpdate();
			connection.commit();
			
		}catch(SQLException | SAXException | IOException | ParserConfigurationException | ClassNotFoundException e) {
			System.out.println(e.getMessage());
		}
		
	}

	@Override
	public void deleteFeedback(String feedbackId) {
		
		if(feedbackId != null && !feedbackId.isEmpty()) {
			
			try {
				
				connection = DBConnection.getDBConnection();
				
				preparedStatement = connection.prepareStatement(QueryUtil.queryByID(CommanConstants.QUERY_ID_DELETE_FEEDBACK));
				preparedStatement.setString(CommanConstants.COLUMN_INDEX_ONE,feedbackId);

				preparedStatement.execute();
				
			}catch(SQLException | SAXException | IOException | ParserConfigurationException | ClassNotFoundException e){
				System.out.println(e.getMessage());

			}finally {
				try {
					
					if(connection != null) {
						connection.close();
					}
					
					if(preparedStatement != null) {
						preparedStatement.close();
					}
					
				}catch(SQLException e){
					System.out.println(e.getMessage());
				}
			}
			
		}
		
	}
	
	
	
	
	
	public ArrayList<String> getFeedbackIds(){
		ArrayList<String> ids = new ArrayList<String>();
		
		try {
			
			connection = DBConnection.getDBConnection();
			preparedStatement = connection.prepareStatement(QueryUtil.queryByID(CommanConstants.QUERY_ID_GET_FEEDBACK_IDS));
		    ResultSet	rs = preparedStatement.executeQuery();
			
			while(rs.next()) {
				ids.add(rs.getString(CommanConstants.COLUMN_INDEX_ONE));
			}
			
		}catch(SQLException | SAXException | IOException | ParserConfigurationException | ClassNotFoundException e) {
			System.out.println(e.getMessage());
		}finally {
			try {
				
				if(connection != null) {
					connection.close();
				}
				
				if(preparedStatement != null) {
					preparedStatement.close();
				}
				
			}catch(SQLException e){
				System.out.println(e.getMessage());
			}
		}
		
		return ids;
	}
	
	

}
