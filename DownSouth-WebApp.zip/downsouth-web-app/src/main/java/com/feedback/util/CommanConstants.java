package com.feedback.util;

public class CommanConstants {
	
	public static final String QUERY_XML = "queryFilePath";
	
	public static final String PROPERTY_FILE = "config.properties";
	
	public static final String TAG_NAME = "query";
	
	public static final String ATTRIBUTE_NAME = "id";
	
	public static final String Comma = ",";
	
	public static final String URL = "url";
	
	public static final String username = "username";
	
	public static final String PASSWORD = "password";
	
	public static final String DRIVER_NAME = "driverName";
	
	public static final int COLUMN_INDEX_ONE = 1;
	public static final int COLUMN_INDEX_TWO = 2;
	public static final int COLUMN_INDEX_THREE = 3;
	public static final int COLUMN_INDEX_FOUR = 4;
	public static final int COLUMN_INDEX_FIVE= 5;
	public static final int COLUMN_INDEX_SIX = 6;

	
	
//Student Constants
	
	public static final String FEEDBACK_ID_PREFIX = "FD110";
	
	public static final String QUERY_ID_CREATE_FEEDBACK_TABLE = "create_feedback_table";

	public static final String QUERY_ID_INSERT_FEEDBACK = "insert_feedback";

	public static final String QUERY_ID_GET_FEEDBACK_IDS = "get_feedback_ids";

	public static final String QUERY_ID_GET_ALL_FEEDBACKS = "get_feedback_all_feedbacks";

	public static final String QUERY_ID_GET_FEEDBACK_BY_ID = "get_feedback_by_id";

	public static final String QUERY_ID_UPDATE_FEEDBACK = "update_feedback";

	public static final String QUERY_ID_DELETE_FEEDBACK = "delete_feedback";




}
